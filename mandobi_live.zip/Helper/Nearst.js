"strict mode";
exports.main = (point, driversObj, reduce) => {
    return Object.keys(Object.keys(driversObj).forEach((obj) => {
        return (obj.id > 2);
    }))
}